console.log("widget.js - start");



/** 
  * Method that removes the users Credentials from the File System.
  */
function testFunc(){
    console.log("testFunc() - start");
    console.log("testFunc() - finish");
}

/** 
  * Method that removes the users Credentials from the File System.
  */
function testToast(){
	//alert("hello");
    console.log("testToast() - start");
	cordova.plugins.toastPlugin.toast('androidToast', function(msg) {  
	  alert(msg);  
	}, function(msg) {  
	  alert(msg);  
	});
    console.log("testToast() - finish");
}


console.log("widget.js - finish");